import './globals.css';
export const metadata={title:'Velvet Pour','description':'Velvet Pour luxury drinks, delivery and business management'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
