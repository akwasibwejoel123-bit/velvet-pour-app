'use client';
import {useMemo,useState} from 'react';
const initialProducts=[
{id:1,name:'Johnnie Walker Black Label',category:'Whisky',price:250000,cost:190000,stock:8},
{id:2,name:'Hennessy VS',category:'Brandy',price:320000,cost:245000,stock:5},
{id:3,name:'Absolut Vodka',category:'Vodka',price:180000,cost:125000,stock:10},
{id:4,name:'Bombay Sapphire Gin',category:'Gin',price:220000,cost:155000,stock:7},
{id:5,name:'Sex on the Beach',category:'Cocktail',price:25000,cost:11000,stock:20},
{id:6,name:'Tequila Sunrise',category:'Cocktail',price:25000,cost:10000,stock:18},
{id:7,name:'Bugolobi Sunrise',category:'Cocktail',price:25000,cost:10500,stock:15},
{id:8,name:'Mudslide',category:'Cocktail',price:28000,cost:12000,stock:12},
{id:9,name:'Shirley Temple',category:'Non-Alcoholic',price:15000,cost:5000,stock:25},
{id:10,name:'Blue Lagoon',category:'Non-Alcoholic',price:15000,cost:5000,stock:25}
];
const zones=[['Wandegeya',5000],['Kololo',7000],['Ntinda',10000],['Nakulabye',10000],['Kampala Central',15000]];
const money=n=>new Intl.NumberFormat('en-UG').format(n);
export default function Home(){
 const [tab,setTab]=useState('Dashboard'); const [products,setProducts]=useState(initialProducts); const [orders,setOrders]=useState([]); const [cart,setCart]=useState([]); const [zone,setZone]=useState('Wandegeya'); const [search,setSearch]=useState(''); const [notice,setNotice]=useState('');
 const sales=orders.reduce((a,o)=>a+o.total,0), profit=orders.reduce((a,o)=>a+o.profit,0), inventory=products.reduce((a,p)=>a+p.stock*p.cost,0);
 const filtered=products.filter(p=>p.name.toLowerCase().includes(search.toLowerCase())||p.category.toLowerCase().includes(search.toLowerCase()));
 function add(p){setCart(c=>{let x=c.find(i=>i.id===p.id); return x?[...c.filter(i=>i.id!==p.id),{...x,qty:x.qty+1}]:[...c,{...p,qty:1}]})}
 function checkout(){if(!cart.length)return; const delivery=zones.find(z=>z[0]===zone)?.[1]||5000; const subtotal=cart.reduce((a,i)=>a+i.price*i.qty,0); const cost=cart.reduce((a,i)=>a+i.cost*i.qty,0); const order={id:Date.now(),items:cart,total:subtotal+delivery,profit:subtotal-cost,delivery,zone,status:'Confirmed',time:new Date().toLocaleTimeString()}; setOrders(o=>[order,...o]); setProducts(ps=>ps.map(p=>{let x=cart.find(i=>i.id===p.id);return x?{...p,stock:p.stock-x.qty}:p})); setCart([]);setNotice('Order confirmed and inventory updated.');setTab('Orders')}
 function updateStock(id,delta){setProducts(ps=>ps.map(p=>p.id===id?{...p,stock:Math.max(0,p.stock+delta)}:p))}
 const nav=['Dashboard','Shop','Cocktails','Delivery','Orders','Inventory','Sales & Profits','Events','Settings'];
 return <div className="app"><aside><div className="brand"><b>♛ VP</b><span>VELVET POUR</span><small>Good Drinks. Better Moments.</small></div>{nav.map(n=><button key={n} className={tab===n?'active':''} onClick={()=>setTab(n)}>{n}</button>)}<div className="age">18+ • Drink Responsibly</div></aside><main><header><div><h1>{tab}</h1><p>Luxury drinks • Cocktails • Delivery • Events</p></div><div className="cart">Cart <b>{cart.reduce((a,i)=>a+i.qty,0)}</b></div></header>{notice&&<div className="notice" onClick={()=>setNotice('')}>{notice}</div>}
 {tab==='Dashboard'&&<><section className="hero"><div><span>PREMIUM SPIRITS</span><h2>Top brands. Best prices.</h2><p>Manage sales, stock, deliveries and event bookings from one place.</p><button onClick={()=>setTab('Shop')}>Open Shop</button></div></section><div className="cards"><Card t="Total Sales" v={'UGX '+money(sales)}/><Card t="Estimated Profit" v={'UGX '+money(profit)}/><Card t="Inventory Value" v={'UGX '+money(inventory)}/><Card t="Orders" v={orders.length}/></div><div className="panel"><h3>Quick actions</h3><div className="quick">{['Shop','Delivery','Inventory','Sales & Profits','Settings'].map(x=><button onClick={()=>setTab(x)} key={x}>{x}</button>)}</div></div></>}
 {tab==='Shop'&&<Shop filtered={filtered} search={search} setSearch={setSearch} add={add}/>} 
 {tab==='Cocktails'&&<Shop filtered={filtered.filter(p=>p.category.includes('Cocktail')||p.category==='Non-Alcoholic')} search={search} setSearch={setSearch} add={add}/>} 
 {tab==='Delivery'&&<Delivery zone={zone} setZone={setZone} cart={cart} checkout={checkout}/>} 
 {tab==='Orders'&&<Orders orders={orders}/>} 
 {tab==='Inventory'&&<Inventory products={products} updateStock={updateStock}/>} 
 {tab==='Sales & Profits'&&<Sales orders={orders} sales={sales} profit={profit}/>} 
 {tab==='Events'&&<Events/>}
 {tab==='Settings'&&<Settings/>}
 </main></div>
}
function Card({t,v}){return <div className="card"><small>{t}</small><strong>{v}</strong></div>}
function Shop({filtered,search,setSearch,add}){return <section><input className="search" placeholder="Search brand, type or category..." value={search} onChange={e=>setSearch(e.target.value)}/><div className="grid">{filtered.map(p=><div className="product" key={p.id}><div className="bottle">VP</div><div><small>{p.category}</small><h3>{p.name}</h3><b>UGX {money(p.price)}</b><button onClick={()=>add(p)}>Add to Cart</button></div></div>)}</div></section>}
function Delivery({zone,setZone,cart,checkout}){const subtotal=cart.reduce((a,i)=>a+i.price*i.qty,0);const fee=zones.find(z=>z[0]===zone)?.[1]||5000;return <section className="panel"><h2>Delivery system</h2><label>Delivery Address<input placeholder="Wandegeya, Kampala"/></label><label>Delivery Zone<select value={zone} onChange={e=>setZone(e.target.value)}>{zones.map(z=><option key={z[0]}>{z[0]}</option>)}</select></label><div className="zones">{zones.map(z=><div key={z[0]}><span>{z[0]}</span><b>UGX {money(z[1])}</b></div>)}</div><hr/><p>Subtotal: <b>UGX {money(subtotal)}</b></p><p>Delivery fee: <b>UGX {money(fee)}</b></p><p>Total: <b>UGX {money(subtotal+fee)}</b></p><button onClick={checkout}>Confirm Order</button></section>}
function Orders({orders}){return <section className="panel"><h2>Order tracking</h2>{!orders.length?<p>No orders yet.</p>:orders.map(o=><div className="order" key={o.id}><b>#{String(o.id).slice(-6)}</b><span>{o.zone}</span><span>{o.status}</span><strong>UGX {money(o.total)}</strong><small>{o.time}</small></div>)}</section>}
function Inventory({products,updateStock}){return <section className="panel"><h2>Inventory tracking</h2>{products.map(p=><div className="stock" key={p.id}><div><b>{p.name}</b><small>{p.category}</small></div><span className={p.stock<5?'low':''}>{p.stock} units</span><button onClick={()=>updateStock(p.id,-1)}>−</button><button onClick={()=>updateStock(p.id,1)}>+</button></div>)}</section>}
function Sales({orders,sales,profit}){return <section><div className="cards"><Card t="Revenue" v={'UGX '+money(sales)}/><Card t="Gross Profit" v={'UGX '+money(profit)}/><Card t="Orders" v={orders.length}/></div><div className="panel"><h2>Sales history</h2>{orders.map(o=><div className="order" key={o.id}><span>#{String(o.id).slice(-6)}</span><span>{o.zone}</span><b>UGX {money(o.total)}</b><strong>Profit UGX {money(o.profit)}</strong></div>)}</div></section>}
function Events(){return <section className="panel"><h2>Book our bartenders</h2><p>Mobile bar for birthdays, weddings, corporate and private events.</p><div className="cards"><Card t="Standard" v="1 Bartender"/><Card t="Premium" v="2 Bartenders"/><Card t="VIP" v="Custom"/></div><button onClick={()=>alert('Event request form ready for connection to your database.')}>Create Event Booking</button></section>}
function Settings(){return <section className="panel"><h2>Settings</h2><label>Business Name<input defaultValue="Velvet Pour"/></label><label>Business Phone<input defaultValue="0791696326"/></label><label>Default Location<input defaultValue="Wandegeya, Kampala"/></label><label>Minimum Order (UGX)<input defaultValue="50000" type="number"/></label><label>Low Stock Alert<input defaultValue="5" type="number"/></label><button onClick={()=>alert('Settings saved locally for this demo.')}>Save Settings</button></section>}
