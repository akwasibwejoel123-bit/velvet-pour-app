# Velvet Pour App

Next.js starter for the Velvet Pour luxury drinks app/business dashboard.

## Included
- Premium dark/gold UI
- Shop and cocktail catalog
- Cart and checkout flow
- Delivery zones and fees
- Order tracking/history
- Inventory stock controls
- Sales and profit dashboard
- Event booking area
- Settings screen

## Run locally
npm install
npm run dev

Then open http://localhost:3000

## Deploy to Vercel
Import this folder/repository into Vercel. Build command: `npm run build`.
